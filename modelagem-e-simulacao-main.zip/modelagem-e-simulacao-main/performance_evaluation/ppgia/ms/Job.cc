#include "Job.h"

namespace ms {

Job::Job(const char *name) : cMessage(name, 0) {

}

};//namespace

